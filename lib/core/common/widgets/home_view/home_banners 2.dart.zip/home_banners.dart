import 'package:amimpact/core/common/models/home_model/banner.dart';
import 'package:amimpact/core/common/widgets/general/cached_image.dart';
import 'package:amimpact/core/products/views/products_view/products_view.dart';
import 'package:amimpact/utils/locator.dart';
import 'package:amimpact/utils/nav_helper.dart';
import 'package:flutter/material.dart';

class HomeBannersWidget extends StatefulWidget {
  const HomeBannersWidget({
    Key? key,
    required this.banners,
  }) : super(key: key);

  final List<HomeBanner> banners;

  @override
  State<HomeBannersWidget> createState() => _HomeBannersWidgetState();
}

class _HomeBannersWidgetState extends State<HomeBannersWidget> {

  @override
  void initState() {
    setBanners();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return widget.banners.isEmpty
        ? const SizedBox.shrink()
        : Builder(builder: (context) {
            final sBanners =
                widget.banners.where((element) => element.size == "S").toList();
            final rBanners =
                widget.banners.where((element) => element.size == "R").toList();

            return Container(
              child: Column(
                children: [
                  ...rBanners
                      .map((banner) => GestureDetector(
                            onTap: banner.path == null
                                ? null
                                : () => locator<NavHelper>().push(
                                      ProductsView(
                                        allowPagination: false,
                                        path: banner.path,
                                        title: banner.bannerName,
                                      ),
                                    ),
                            child: Container(
                              margin: const EdgeInsets.only(
                                top: 8,
                              ),
                              // height: 150,
                              // width: MediaQuery.of(context).size.width - 40,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: CachedImage(
                                  fit: BoxFit.fitHeight,
                                  url: banner.bannerImg,
                                ),
                              ),
                            ),
                          ))
                      .toList(),
                  SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    // height: 150,
                    child: ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: sBanners.length,
                      itemBuilder: (_, index) {
                        final banner = sBanners[index];
                        return GestureDetector(
                          onTap: banner.path == null
                              ? null
                              : () => locator<NavHelper>().push(
                                    ProductsView(
                                      allowPagination: false,
                                      path: banner.path,
                                      title: banner.bannerName,
                                    ),
                                  ),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            // height: 150,
                            // width: banner.size == "S"
                            //     ? 300
                            //     : MediaQuery.of(context).size.width - 40,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CachedImage(
                                fit: BoxFit.fitHeight,
                                url: banner.bannerImg,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          });
  }

  void setBanners() {}
}
