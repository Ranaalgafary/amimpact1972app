import 'package:amimpact/core/common/models/home_model/banner.dart';
import 'package:amimpact/core/common/widgets/general/cached_image.dart';
import 'package:amimpact/core/products/views/products_view/products_view.dart';
import 'package:amimpact/utils/locator.dart';
import 'package:amimpact/utils/nav_helper.dart';
import 'package:flutter/material.dart';

class HomeBannersWidget extends StatelessWidget {
  const HomeBannersWidget({
    Key? key,
    required this.banners,
  }) : super(key: key);

  final List<HomeBanner> banners;

  @override
  Widget build(BuildContext context) {
    return banners.isEmpty
        ? const SizedBox.shrink()
        : Builder(builder: (context) {
            final sBanners =
                banners.where((element) => element.size == "S").toList();
            final rBanners =
                banners.where((element) => element.size == "R").toList();

            return Column(
              children: [
                ...rBanners
                    .map((banner) => GestureDetector(
                          onTap: banner.path == null
                              ? null
                              : () => locator<NavHelper>().push(
                                    ProductsView(
                                      allowPagination: false,
                                      path: banner.path,
                                      title: banner.bannerName,
                                    ),
                                  ),
                          child: Container(
                            margin: const EdgeInsets.only(
                                left: 8, top: 8, bottom: 8),
                            height: 150,
                            width: MediaQuery.of(context).size.width - 40,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CachedImage(
                                fit: BoxFit.fill,
                                url: banner.bannerImg,
                              ),
                            ),
                          ),
                        ))
                    .toList(),
                SizedBox(
                  height: 150,
                  child: ListView.builder(
                    itemCount: sBanners.length,
                    itemBuilder: (_, index) {
                      final banner = sBanners[index];
                      return GestureDetector(
                        onTap: banner.path == null
                            ? null
                            : () => locator<NavHelper>().push(
                                  ProductsView(
                                    allowPagination: false,
                                    path: banner.path,
                                    title: banner.bannerName,
                                  ),
                                ),
                        child: Container(
                          margin: const EdgeInsets.only(left: 8),
                          height: 150,
                          width: banner.size == "S"
                              ? 300
                              : MediaQuery.of(context).size.width - 40,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: CachedImage(
                              fit: BoxFit.fill,
                              url: banner.bannerImg,
                            ),
                          ),
                        ),
                      );
                    },
                    scrollDirection: Axis.horizontal,
                  ),
                ),
              ],
            );
          });
  }
}
